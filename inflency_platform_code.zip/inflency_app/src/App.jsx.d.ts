declare module './App.jsx' {
  import { FC } from 'react';
  const App: FC;
  export default App;
}
